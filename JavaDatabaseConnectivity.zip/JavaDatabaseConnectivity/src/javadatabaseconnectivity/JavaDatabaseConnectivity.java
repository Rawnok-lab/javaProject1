package javadatabaseconnectivity;
public class JavaDatabaseConnectivity {
    //public static void main(String[] args) {
        
    //}
    
}
